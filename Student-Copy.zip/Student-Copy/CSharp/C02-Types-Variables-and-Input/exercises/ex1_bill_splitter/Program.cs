Console.Write("Total bill: ");
