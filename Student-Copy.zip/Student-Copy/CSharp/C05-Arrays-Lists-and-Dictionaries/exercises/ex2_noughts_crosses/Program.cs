char[,] board = new char[3, 3];
