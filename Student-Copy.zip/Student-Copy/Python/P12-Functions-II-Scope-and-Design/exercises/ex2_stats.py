def mean(nums):
    pass
