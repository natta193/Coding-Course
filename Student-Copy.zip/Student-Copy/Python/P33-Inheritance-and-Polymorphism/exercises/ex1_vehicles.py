class Vehicle:
    pass
