class Rectangle:
    pass
