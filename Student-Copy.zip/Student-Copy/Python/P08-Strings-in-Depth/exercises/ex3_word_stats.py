sentence = input("Sentence: ")
